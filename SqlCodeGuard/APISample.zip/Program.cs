﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using SqlCodeGuardAPI;

namespace APISample
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("Usage: Sample.exe <script file name> [<char page>]");
                return;
            }
            Encoding encoding = args.Length == 2 ? Encoding.GetEncoding(int.Parse(args[1])) : Encoding.Default;

            string sql;
            using (StreamReader sr = new StreamReader(args[0], encoding))
            {
                sql = sr.ReadToEnd();
            }
            API api = new API();
            /*print all available issues*/
            foreach (IssueInfo i in api.SupportedIssueList)
            {
                Console.WriteLine("{0} {1} {2} {3}",i.Code,i.Title,i.Description,i.Category);
            }
            /*include ALL issues*/
            api.IncludeIssue("ALL");
            /*exclude single issue*/
            api.ExcludeIssue("DEP023");
            bool unparsed;
            List<Issue> l = api.GetIssues(sql, out unparsed);
            if (unparsed)
            {
                Console.WriteLine("Unparsed! Issue list may be incomplete or wrong");
            }
            Console.WriteLine("Issues:");
            foreach (Issue i in l)
            {
                Console.WriteLine(String.Format("({0}){1} at {2}:{3} ({4})", i.ErrorCode, i.ErrorText, i.Column, i.Line, i.ErrorMessage));
            }
            double complexity; int statementCount;
            api.GetComplexity(sql,out unparsed,out complexity,out statementCount);
            Console.WriteLine("Complexity:{0}, Statement Count:{1}",complexity,statementCount);

        }
    }
}
