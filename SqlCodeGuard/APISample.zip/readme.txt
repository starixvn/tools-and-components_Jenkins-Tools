﻿How to build sample?
Well... if you really need it - you know what to do
Simply don't forget to copy SqlCodeGuard.API.dll to project's directory.
